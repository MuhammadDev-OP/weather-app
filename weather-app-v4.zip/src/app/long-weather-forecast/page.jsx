import Hero2 from "../components/widgets/Hero2"
import SeasonalOutlook from "./SeasonalOutlook"

const page = () => {
    return (
        <>
            <Hero2 />
            <SeasonalOutlook />
        </>
    )
}
export default page
